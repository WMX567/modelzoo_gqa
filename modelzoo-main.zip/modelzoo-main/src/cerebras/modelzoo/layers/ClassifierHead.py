# Copyright 2022 Cerebras Systems.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import torch.nn as nn


class ClassifierHead(nn.Module):
    def __init__(self, in_channels, num_classes, dropout_rate=0.0):
        super(ClassifierHead, self).__init__()
        self.pool = nn.AdaptiveAvgPool2d(output_size=(1, 1))
        self.dropout = nn.Dropout(p=dropout_rate) if dropout_rate else None
        self.flatten = nn.Flatten(start_dim=1)
        self.fc = nn.Linear(in_channels, out_features=num_classes)

    def forward(self, inputs):
        outputs = self.pool(inputs)
        if self.dropout:
            outputs = self.dropout(outputs)
        outputs = self.flatten(outputs)
        outputs = self.fc(outputs)
        return outputs
